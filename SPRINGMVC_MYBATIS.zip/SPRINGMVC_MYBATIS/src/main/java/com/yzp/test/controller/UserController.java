package com.yzp.test.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.yzp.test.entity.User;
import com.yzp.test.service.impl.UserServiceImpl;


@RestController
public class UserController {
	@Autowired
	private UserServiceImpl userServiceImpl;
	
	@RequestMapping("/add/user.do")
	@ResponseBody
	public String pictureUpload(MultipartFile uploadFile) {
		System.out.println("进入了controller");
		User user = new User();
		user.setUsername("yang");
		user.setAge(21);
		Integer result = userServiceImpl.addUser(user);
		if(result==2) {
			System.out.println("失败");
			return "失败";
		}
		System.out.println("成功");
		return "成功";
	}
}
