package com.yzp.test.service;

import com.yzp.test.entity.User;

public interface UserService {
	Integer addUser(User user);
}
