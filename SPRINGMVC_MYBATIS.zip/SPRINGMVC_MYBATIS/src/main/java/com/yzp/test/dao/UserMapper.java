package com.yzp.test.dao;

import com.yzp.test.entity.User;

public interface UserMapper {
	//插入数据
	Integer insert(User user);
}
