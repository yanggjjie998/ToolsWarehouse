package com.yzp.test.service.impl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yzp.test.dao.UserMapper;
import com.yzp.test.entity.User;
import com.yzp.test.service.UserService;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	private UserMapper userMapper;
	
	@Override
	public Integer addUser(User user) {
		Integer result = userMapper.insert(user);
		if(result!=1) {
			return 2;
		}
		return 1;
	}

}
