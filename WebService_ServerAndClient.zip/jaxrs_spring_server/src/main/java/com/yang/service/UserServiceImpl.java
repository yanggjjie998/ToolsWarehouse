package com.yang.service;

import com.yang.entity.Car;
import com.yang.entity.User;

import java.util.ArrayList;
import java.util.List;

public class UserServiceImpl implements IUserService{
    @Override
    public void saveUser(User user) {
        System.out.println("save user:"+user);
    }

    @Override
    public void updateUser(User user) {
        System.out.println("update user:"+user);
    }

    @Override
    public List<User> findAllUser() {
        List<User> users = new ArrayList<>();
        User user1 = new User();
        user1.setId(1);
        user1.setUsername("小明");
        user1.setCity("重庆");

        User user2 = new User();
        user2.setId(2);
        user2.setUsername("小丽");
        user2.setCity("上海");

        users.add(user1);
        users.add(user2);

        List<Car> carList1 = new ArrayList<>();
        Car car1 = new Car();
        car1.setId(101);
        car1.setCarName("保时捷");
        car1.setPrice(1000000d);
        Car car2 = new Car();
        car2.setId(103);
        car2.setCarName("宝马");
        car2.setPrice(9999999d);

        carList1.add(car1);
        carList1.add(car2);

        return users;
    }

    @Override
    public User findUserById(Integer id) {
        if (id==1){
            User user1 = new User();
            user1.setId(1);
            user1.setUsername("小明");
            user1.setCity("重庆");
            return user1;
        }
        return null;
    }

    @Override
    public void deleteUser(Integer id) {
        System.out.println("delete user id:"+id);
    }
}
