package com.yang.service;

import com.yang.entity.User;

import javax.ws.rs.*;
import java.util.List;

/**
 * @Path("/userService") 访问当前服务接口对应的路径
 * @Produces("*\\/*") 支持任意类型
 */
@Path("/userService")
@Produces("*/*")
public interface IUserService {

    /**
     * @POST 处理的请求类型 post对应的是insert新增操作
     *  @Path("/user") 访问当前接口方法的路径
     */
    @POST
    @Path("/user")
    @Consumes({"application/xml","application/json"})
    public void saveUser(User user);

    /**
     * @POST 处理的请求类型 post对应的是update操作
     */
    @PUT
    @Path("/user")
    @Consumes({"application/xml","application/json"})
    public void updateUser(User user);

    /**
     * @GET 处理的请求类型 post对应的是select操作
     */
    @GET
    @Path("/user")
    @Produces({"application/xml","application/json"})
    public List<User> findAllUser();

    @GET
    @Path("/user/{id}")
    @Consumes({"application/xml"})
    @Produces({"application/xml","application/json"})
    public User findUserById(@PathParam("id") Integer id);

    @DELETE
    @Path("/user/{id}")
    @Consumes({"application/xml","application/json"})
    public void deleteUser(@PathParam("id") Integer id);


}
