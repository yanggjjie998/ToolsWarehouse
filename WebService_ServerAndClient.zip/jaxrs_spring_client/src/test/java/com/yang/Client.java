package com.yang;

import com.yang.entity.User;
import org.apache.cxf.jaxrs.client.WebClient;
import org.junit.Test;

import javax.ws.rs.core.MediaType;

public class Client {

    @Test
    public void testSave(){
        User user = new User();
        user.setId(1);
        user.setUsername("小明");
        user.setCity("重庆");
        //通过webClicent对象远程调用服务端
        WebClient
                .create("http://localhost:8080/ws/userService/userService/user")
                .type(MediaType.APPLICATION_JSON)//指定请求的数据格式为json
                .post(user);
    }

    @Test
    public void testGet(){
        User user =
        //通过webClicent对象远程调用服务端
        WebClient
                .create("http://localhost:8080/ws/userService/userService/user/1")
                .accept(MediaType.APPLICATION_JSON)//指定请求的数据格式为json
                .get(User.class);
        System.out.println(user);

    }

    @Test
    public void testGetAllUser(){
        WebClient
                .create("http://localhost:8001/ws/userService/user")
                .accept(MediaType.APPLICATION_JSON)//指定请求的数据格式为json
                .get(User.class);

    }

    @Test
    public void testDelete(){
                //通过webClicent对象远程调用服务端
                WebClient
                        .create("http://localhost:8001/ws/userService/user/1")
                        .accept(MediaType.APPLICATION_JSON)//指定请求的数据格式为json
                        .delete();

    }
}
