package com.tai.userService.utils;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.commons.dbcp.BasicDataSource;

public class DBUtils {
	private static BasicDataSource source;

	static {
		try {
			Properties pro = new Properties();
			InputStream is = DBUtils.class.getClassLoader().getResourceAsStream("jdbc.properties");
			pro.load(is);
			String driver = pro.getProperty("driver");
			String url = pro.getProperty("url");
			String username = pro.getProperty("username");
			String password = pro.getProperty("password");
			source = new BasicDataSource();
			source.setDriverClassName(driver);
			source.setUrl(url);
			source.setUsername(username);
			source.setPassword(password);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static Connection getConn() throws SQLException {
		return source.getConnection();
	}
	
}
