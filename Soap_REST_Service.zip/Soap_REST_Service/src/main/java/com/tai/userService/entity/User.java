package com.tai.userService.entity;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="user")
@XmlType(propOrder= {"ukey","userid","pwd","name","status"})
public class User {
	private Integer ukey;
	private String userid;
	private String pwd;
	private String name;
	private String status;

	public User() {
	}

	public User(Integer ukey, String userid, String pwd, String name, String status) {
		super();
		this.ukey = ukey;
		this.userid = userid;
		this.pwd = pwd;
		this.name = name;
		this.status = status;
	}

	public Integer getUkey() {
		return ukey;
	}

	public void setUkey(Integer ukey) {
		this.ukey = ukey;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
