package com.tai.userService.rest;

import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.tai.userService.entity.User;

@Path("userService")
@Produces(MediaType.APPLICATION_XML)
public interface UserService {

	/**
	 * 查询所有用户信息
	 * 
	 * @return 所有用户的信息
	 */
	@GET
	@Path("user")
	@Produces(MediaType.APPLICATION_XML)
	public List<User> getAllUsers();

	/**
	 * 查询指定用户信息
	 * 
	 * @param id 用户id
	 * @return 指定id的用户的信息
	 */
	@GET
	@Path("user/{id}")
	@Produces(MediaType.APPLICATION_XML)
	public User getUserInfo(@PathParam("id") Integer id);

	/**
	 * 添加用户
	 * 
	 * @param user 用户信息
	 */
	@POST
	@Path("user")
	public void addUser(User user);

	/**
	 * 把指定用户的状态改为enable
	 * 
	 * @param id 用户id
	 */
	@POST
	@Path("user/{id}")
	public void enableUser(@PathParam("id") Integer id);

	/**
	 * 修改用户信息
	 * 
	 * @param user 用户信息
	 */
	@PUT
	@Path("user")
	public void updataUser(User user);

	/**
	 * 把指定用户的状态改为disable
	 * 
	 * @param id 用户id
	 */
	@DELETE
	@Path("user/{id}")
	public void disableUser(@PathParam("id") Integer id);

}
