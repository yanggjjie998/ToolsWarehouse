package com.tai.userService.soap.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.jws.WebService;

import com.tai.userService.entity.User;
import com.tai.userService.soap.UserService;
import com.tai.userService.utils.DBUtils;

@WebService(portName="soap",serviceName="WSServlet")
public class UserServiceImpl implements UserService {
	public static Connection conn = null;

	static {
		try {
			conn = DBUtils.getConn();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<User> getUsersInfo() {
		List<User> list = new ArrayList<User>();
		try {
			String sql = "SELECT ukey,userid,pwd,name,status FROM t_user";
			PreparedStatement pre = conn.prepareStatement(sql);
			ResultSet rest = pre.executeQuery();
			while (rest.next()) {
				list.add(new User(rest.getInt(1), rest.getString(2), rest.getString(3), rest.getString(4),
						rest.getString(5)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public User getUserInfo(Integer id) {
		User user = null;
		try {
			String sql = "SELECT ukey,userid,pwd,name,status FROM t_user WHERE ukey=?";
			PreparedStatement pre = conn.prepareStatement(sql);
			pre.setInt(1, id);
			ResultSet rest = pre.executeQuery();
			while (rest.next()) {
				user = new User(rest.getInt(1), rest.getString(2), rest.getString(3), rest.getString(4),
						rest.getString(5));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return user;
	}

}
